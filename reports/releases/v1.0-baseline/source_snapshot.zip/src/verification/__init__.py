"""Evidence verification components."""
